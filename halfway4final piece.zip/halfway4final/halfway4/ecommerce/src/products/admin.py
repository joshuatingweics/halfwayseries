from django.contrib import admin
from django.db.models.query import QuerySet
from .models import Product
from django.contrib.auth import get_user_model

User=get_user_model()
class ProductAdmin(admin.ModelAdmin):
    list_display = ['__str__', 'slug','timestamp','telegram','owner']

    def get_queryset(self, request):
        """Limit Pages to those that belong to the request's user."""
        qs = super(ProductAdmin, self).get_queryset(request)
        if request.user.is_superuser:
            return qs
        return qs.filter(owner=request.user)

    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "owner":
            kwargs["queryset"] = User.objects.filter(username__in=[request.user])
        return super().formfield_for_foreignkey(db_field, request, **kwargs)


    class Meta:
        model = Product

admin.site.register(Product, ProductAdmin)
